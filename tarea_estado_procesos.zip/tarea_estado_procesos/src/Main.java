//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {

    String so = System.getProperty("os.name").toLowerCase();

    String[] comando;

    if (so.contains("win")) {
        comando = new String[]{"ping", "-n" + "4" + "localhost"};
    } else {
        comando = new String[]{"ping", "-c", "4", "localhost"};
    }

    try {
        ProcessBuilder pb = new ProcessBuilder(comando);
        pb.redirectErrorStream(true); //unificacion de salida normal con salida de errores
        Process p = pb.start(); //inicializacion del proceso
        //Obtencion de la informacion del proceso(parte 1):
        ProcessHandle informacion = p.toHandle();

        ProcessHandle.Info info = informacion.info();

        System.out.println("INFORMACIÓN DEL PROCESO");
        System.out.println("\n");

        System.out.println("Vivo?: " + p.isAlive());
        System.out.println("PID: " + p.pid());
        System.out.println("Comando: " + info.command().orElse("Comando no disponible =("));
        System.out.println("Argumentos: " + Arrays.toString(info.arguments().orElse(new String[0])));
        System.out.println("Usuario: " + info.user().orElse("Usuario no disponible"));
        System.out.println("\n");

        System.out.println("RESULTADO DEL PING");
        System.out.println("\n");

        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String linea;
        while((linea = br.readLine())!= null){
            System.out.println(linea);
        }

        br.close();

        int resultado = p.waitFor();
        System.out.println("\n");

        System.out.println("RESULTADO FINAL");
        System.out.println("\n");

        System.out.println("Codigo de salida: " + resultado);
        System.out.println("Vivo?: " + p.isAlive());
        if (resultado == 0){
            System.out.println("El proceso a finalizado correctamente ;)");
        }else{
            System.out.println("El proceso a finalizado con errores =(");
        }


    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (InterruptedException e) {
        throw new RuntimeException(e);
    }

}
